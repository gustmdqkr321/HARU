package com.example.haru;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class mood_choice extends Activity {
    Button nowday;
    String mood;
    Button.OnClickListener t = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            nowday = (Button) v;
            Toast.makeText(getApplicationContext(),"위치 설정 ok "+ nowday.getId(),Toast.LENGTH_SHORT).show();
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mood_choice);
        ImageView background = (ImageView)findViewById(R.id.background);
        final RadioGroup RG = (RadioGroup)findViewById(R.id.RG);
        final RadioButton happy = (RadioButton)findViewById(R.id.happy);
        final RadioButton soso = (RadioButton)findViewById(R.id.soso);
        final RadioButton sad = (RadioButton)findViewById(R.id.sad);
        final RadioButton angry = (RadioButton)findViewById(R.id.angry);
        Button day1 =(Button)findViewById(R.id.day1);
        Button day2 =(Button)findViewById(R.id.day2);
        Button moodchoice = (Button)findViewById(R.id.moodchoice);
        moodchoice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        int id = RG.getCheckedRadioButtonId();

                        if(happy.getId() == id){
                            mood = "#fff000";
                        }
                        else if(soso.getId() == id){
                            mood = "#00ff95";
                        }
                        else if(sad.getId() == id){
                            mood = "#0000ff";
                        }
                        else{
                            mood = "#ff0000";
                        }
                        nowday.setBackgroundColor(Color.parseColor(mood));
                        nowday.bringToFront();
                    }
                });
        day1.setOnClickListener(t);
        day2.setOnClickListener(t);
    }
}


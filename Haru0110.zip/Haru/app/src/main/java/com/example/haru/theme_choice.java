package com.example.haru;

import android.app.Activity;
import android.os.Bundle;

public class theme_choice extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.theme_choice);
    }
}
